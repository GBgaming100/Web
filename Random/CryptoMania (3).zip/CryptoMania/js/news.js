//get all characters
function getNews() {

    $.ajax({
        type: "GET",
        dataType: "json",
        url: "https://min-api.cryptocompare.com/data/v2/news/?lang=EN",

        success: function (data) {

        //    console.log(data['Data']);

            var NewsApi = data['Data'];

            console.log(NewsApi);
        }
    });
}

$(document).ready(function () {

    //load all news articals
    getNews();
});



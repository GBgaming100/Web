$(document).ready(function () {
    //closes shopping cart at start of the page
    $(".shopping-cart").fadeToggle( "fast");

    //On click to get a character
    $(".btn").on("click", ".btn_add_js", function(){
        var gameId = $(this).attr("value");
        addToCart(gameId);
    });

    cart();
});

function addToCart(gameId) {
    console.log(gameId);
    $.ajax({
        type: 'POST',
        url: "inc/add_to_cart.php",
        data: {
            gameID: gameId,
        },
        success: function (data) {
            console.log(data);


        }
    })
}

function cart(){
 
    $("#cart").on("click", function() {
      $(".shopping-cart").fadeToggle( "fast");
    });
    
  }
<?php
session_start();

include "functions.php";

if ($_SESSION['cart'] == ''){
    $_SESSION['cart'] = array();
}

$gameID = $_POST['gameID'];

array_push($_SESSION['cart'],$gameID);

var_dump($_SESSION['cart']);

?>
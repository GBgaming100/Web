
function getallCoinsWallet() {
    $.ajax({
        type: "GET",
        url: "inc/get_coins_db.php",
        dataType: "json",

        success:function (data) {
            console.table(data);


            var template = $("#all-coins-template").html();

            var renderTemplate = Mustache.render(template, data);

            $("#crypto-folio-table").html(renderTemplate);
        }
    })
}

function updateCoin(getSaveButton) {

    var row = $(getSaveButton).closest("tr");

    var coinName = row.find('.coin-name').text();
    var coinId = row.find('.coin-id').text();
    var coinPrice = row.find('.coin-price').text();
    var coinAmount = row.find('.amount-input').val();
    var coinValue = row.find('.coin-value').text();



    $.ajax({
        type: "POST",
        url: "inc/save_coin_db.php",
            data:{
                coin_name: coinName,
                coin_Id: coinId,
                coin_Price: coinPrice,
                coin_Amount: coinAmount,
                coin_Value: coinValue,
        },

        success: function(data){

            //see the console in your browser
            console.log(data);

            getallCoinsWallet();


        }
    })
}

$(document).ready(function () {
    getallCoinsWallet();

    //On click event to update the amount of coins
    $(document).on("click", ".save-coin-btn", function(){

        updateCoin(this);

    });
});
